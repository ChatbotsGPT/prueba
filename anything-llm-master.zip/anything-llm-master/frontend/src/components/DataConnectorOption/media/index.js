import Github from "./github.png";
import YouTube from "./youtube.png";

const ConnectorImages = {
  github: Github,
  youtube: YouTube,
};

export default ConnectorImages;
